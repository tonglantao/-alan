import os
import numpy as np
import cv2

# get .txt document
root_dir = r'D:\lbq\code\mm\mmsegmentation\data\VOCdevkit\VOC2012_3\JPEGImages_source'
seg_dir = './SegmentationClass'
rootdir = os.path.join(root_dir)
# read
train_path = open('train.txt', 'w')
val_path = open('val.txt', 'w')
for (dirpath, dirnames, filenames) in os.walk(seg_dir):
    for i, filename in enumerate(filenames):
        # #old_1 = os.path.join(root_dir, filename)
        # old_2 = os.path.join(seg_dir, filename)
        # #new_1 = os.path.join(root_dir, str(i) + '.jpg')
        # new_2 = os.path.join(seg_dir, str(i) + '.png')
        # #os.rename(old_1, new_1)
        # os.rename(old_2, new_2)
        t_or_v = np.random.uniform(low=0.0, high=1.0, size=None)
        if t_or_v > 0.1:
            train_path.write(filename[:-4] + '\n')
        else:
            val_path.write(filename[:-4] + '\n')
train_path.close()
val_path.close()
